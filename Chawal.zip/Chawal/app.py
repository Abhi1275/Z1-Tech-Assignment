from flask import Flask, render_template, request, redirect, url_for, flash
from PIL import Image
import os
import tweepy
from PIL import Image, ImageOps
from PIL.Image import Resampling  # Import Resampling for resizing


app = Flask(__name__)
app.secret_key = "your_secret_key_here"
app.config['UPLOAD_FOLDER'] = 'uploads/'

API_KEY = "KTFcNJQC8hf14bTxpZ1lM8SIf"
API_SECRET_KEY = "wEv03vKIaCBPhXj74mmCDIMTvPeJ0Ifs4YZ9xLtvfx1yed0S9e"
ACCESS_TOKEN = "1754952939301462016-uEPgdazQbXLw6Vc6dvMgcI9EJRUs96"
ACCESS_TOKEN_SECRET = "89gtcTyNM1DWEUE2BAzDnlvNt3gtEzsEJ1bavatyRNRWq"

auth = tweepy.OAuth1UserHandler(API_KEY, API_SECRET_KEY, ACCESS_TOKEN, ACCESS_TOKEN_SECRET)
api = tweepy.API(auth)

DEFAULT_SIZES = [(300, 250), (728, 90), (160, 600), (300, 600)]

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        if "image" not in request.files:
            flash("No file part")
            return redirect(request.url)
        
        file = request.files["image"]
        if file.filename == "":
            flash("No selected file")
            return redirect(request.url)
        
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
        file.save(filepath)

        try:
            resized_images = resize_image(filepath)

            post_to_x(resized_images)

            flash("Images successfully processed and posted to X!")
        except Exception as e:
            flash(f"An error occurred: {str(e)}")
        finally:
            if os.path.exists(filepath):
                os.remove(filepath)

        return redirect(url_for("index"))

    return render_template("index.html")



def resize_image(filepath):
    """Resize the uploaded image to predefined or custom sizes."""
    img = Image.open(filepath)
    resized_images = []

    for size in DEFAULT_SIZES:
        # Use Resampling.LANCZOS instead of ANTIALIAS
        resized_img = img.resize(size, Resampling.LANCZOS)
        resized_path = f"{filepath}_resized_{size[0]}x{size[1]}.png"
        resized_img.save(resized_path)
        resized_images.append(resized_path)

    return resized_images

def post_to_x(image_paths):
    """Post resized images to the user's X timeline."""
    media_ids = []
    for path in image_paths:
        media = api.media_upload(path)
        media_ids.append(media.media_id)

    api.update_status(status="Here are my resized images!", media_ids=media_ids)

if __name__ == "__main__":
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    app.run(debug=True)